from django.shortcuts import render,redirect
from app.models import BioData
from django.views.generic import DetailView
from easy_pdf.views import PDFTemplateView,PDFTemplateResponseMixin

# Create your views here.



def fetch_biodata_data(request,id):#id=1
    biodata_list=BioData.objects.get(id=id)
    context={
        'biodata_list':biodata_list
    }
    return render(request,"biodata.html",context)


def create_biodata_form(request):
    if request.method == "POST":
       name=request.POST.get('name')
       birthname=request.POST.get('birthname')
       birthtime=request.POST.get('birthtime')
       birthplace=request.POST.get('birthplace')
       gothram=request.POST.get('gothram')
       age=request.POST.get('age')
       complexion=request.POST.get('complexion')
       cast=request.POST.get('cast')
       weight=request.POST.get('weight')
       height=request.POST.get('height')
       bloodgroup=request.POST.get('bloodgroup')
       education=request.POST.get('education')
       mobileno=request.POST.get('mobileno')
       occupation=request.POST.get('occupation')
       veg_nonveg=request.POST.get('veg_nonveg')
       expectationfrompartner=request.POST.get('expectationfrompartner')
       fathername=request.POST.get('fathername')
       fathersoccupation=request.POST.get('fathersoccupation')
       mothername=request.POST.get('mothername')
       residentialaddress=request.POST.get('residentialaddress')



       r=BioData(name=name,birthname=birthname,birthtime=birthtime,birthplace=birthplace,gothram=gothram,age=age,
       complexion=complexion,cast=cast,weight=weight,height=height,bloodgroup=bloodgroup,education=education,mobileno=mobileno,occupation=occupation,
       veg_nonveg=veg_nonveg,expectationfrompartner=expectationfrompartner,fathername=fathername,fathersoccupation=fathersoccupation,
       mothername=mothername,residentialaddress=residentialaddress)
       r.save()
       return redirect("/home")
        
    return render(request,"biodataform.html")  


def home_view(request):
    all_biodata=BioData.objects.all()
    return render(request,"home.html",{'all_biodata':all_biodata})

    
class PDFUserDetailView(PDFTemplateResponseMixin, DetailView):
    model = BioData
    template_name = 'user_detail.html'
    context_object_name = "obj"