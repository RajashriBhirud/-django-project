from django.contrib import admin

from app.models import BioData

# Register your models here.

class BioDataAdmin(admin.ModelAdmin):
    list_display=['name']



admin.site.register(BioData,BioDataAdmin)