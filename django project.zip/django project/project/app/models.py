from django.db import models

# Create your models here.


class BioData(models.Model):
    profilepic=models.CharField(max_length=300)
    name=models.CharField(max_length=100)
    birthname=models.CharField(max_length=50)
    birthtime=models.IntegerField()
    birthplace=models.CharField(max_length=50)
    gothram=models.CharField(max_length=50)
    age=models.IntegerField()
    complexion=models.CharField(max_length=50)
    cast=models.CharField(max_length=100)
    weight=models.IntegerField()
    height=models.IntegerField()
    bloodgroup=models.CharField(max_length=50)
    education=models.CharField(max_length=50)
    mobileno=models.IntegerField()
    occupation=models.TextField()
    veg_nonveg=models.CharField(max_length=50)
    expectationfrompartner=models.TextField()
    fathername=models.CharField(max_length=100)
    fathersoccupation=models.CharField(max_length=100)
    mothername=models.CharField(max_length=50)
    residentialaddress=models.TextField()
  

    


